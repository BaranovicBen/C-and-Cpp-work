#ifndef __PROGTEST__
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <climits>
#include <cstdint>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <optional>
#include <memory>
#include <stdexcept>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#endif /* __PROGTEST__ */

struct Export {
    std::string name;
    uint32_t offset;
};

struct Import {
    std::string name;
    std::vector<uint32_t> reference; 
};

struct Source {
    std::string fileName;
    std::vector<Export> exports;
    std::vector<Import> imports;
    std::vector<uint8_t> code;
};

struct CLinker {
    CLinker() = default;
    ~CLinker() = default;
    CLinker(const CLinker &) = delete;
    CLinker & operator=(const CLinker &) = delete;

    std::vector<Source> m_ObjectFiles;

    uint32_t findFunctionEnd(const Source* src, const Export* exp) const {
        uint32_t end = src->code.size();
        for (const auto & e : src->exports) {
            if (e.offset > exp->offset && e.offset < end)
                end = e.offset;
        }
        return end;
    }

    CLinker & addFile(const std::string & fileName) {
        std::ifstream file(fileName, std::ios::binary);
        if (!file)
            throw std::runtime_error("Unable to open file: " + fileName);

        std::vector<uint8_t> buffer((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        if (buffer.size() < 12)
            throw std::runtime_error("File too small or corrupted: " + fileName);

        std::cout << "[addFile] Loading file: " << fileName << ", total size: " << buffer.size() << " bytes" << std::endl;

        size_t offset = 0;
        auto readUint32 = [&](size_t &pos) -> uint32_t {
            if (pos + 4 > buffer.size())
                throw std::runtime_error("Unexpected end of file");
            uint32_t val = buffer[pos] | (buffer[pos + 1] << 8) | (buffer[pos + 2] << 16) | (buffer[pos + 3] << 24);
            pos += 4;
            return val;
        };

        uint32_t numExports = readUint32(offset);
        uint32_t numImports = readUint32(offset);
        uint32_t codeSize   = readUint32(offset);

        std::cout << "[addFile] Exports: " << numExports << ", Imports: " << numImports << ", Code size: " << codeSize << std::endl;

        Source src;
        src.fileName = fileName;

        for (uint32_t i = 0; i < numExports; ++i) {
            if (offset >= buffer.size())
                throw std::runtime_error("Unexpected end of export section");

            uint8_t nameLen = buffer[offset++];
            if (offset + nameLen + 4 > buffer.size())
                throw std::runtime_error("Invalid export record");

            std::string name(reinterpret_cast<const char*>(&buffer[offset]), nameLen);
            offset += nameLen;

            uint32_t funcOffset = readUint32(offset);
            src.exports.push_back({ name, funcOffset });

            std::cout << "[addFile] Exported function: " << name << ", offset: " << funcOffset << std::endl;
        }

        for (uint32_t i = 0; i < numImports; ++i) {
            if (offset >= buffer.size())
                throw std::runtime_error("Unexpected end of import section");

            uint8_t nameLen = buffer[offset++];
            if (offset + nameLen + 4 > buffer.size())
                throw std::runtime_error("Invalid import record");

            std::string name(reinterpret_cast<const char*>(&buffer[offset]), nameLen);
            offset += nameLen;

            uint32_t refCount = readUint32(offset);
            if (offset + refCount * 4 > buffer.size())
                throw std::runtime_error("Invalid import reference count");

            std::vector<uint32_t> refs;
            for (uint32_t j = 0; j < refCount; ++j) {
                refs.push_back(readUint32(offset));
            }

            src.imports.push_back({ name, refs });

            std::cout << "[addFile] Imported function: " << name << ", references: ";
            for (auto r : refs)
                std::cout << r << " ";
            std::cout << std::endl;
        }

        if (offset + codeSize > buffer.size())
            throw std::runtime_error("Invalid code size");

        src.code.insert(src.code.end(), buffer.begin() + offset, buffer.begin() + offset + codeSize);
        std::cout << "[addFile] Loaded code block of size: " << codeSize << " bytes" << std::endl;

        m_ObjectFiles.push_back(std::move(src));
        return *this;
    }

    void linkOutput(const std::string & outFileName, const std::string & entryPoint) {
        std::unordered_map<std::string, std::pair<const Source*, const Export*>> symbolMap;
        std::unordered_map<std::string, uint32_t> resolvedAddresses;
        std::vector<std::pair<const Source*, const Export*>> orderedFunctions;
        std::queue<std::string> toProcess;

        std::cout << "[linkOutput] Entry point: " << entryPoint << std::endl;

        for (const auto & src : m_ObjectFiles) {
            for (const auto & exp : src.exports) {
                std::cout << "[linkOutput] Found export: " << exp.name << " in file " << src.fileName << std::endl;
                if (symbolMap.count(exp.name))
                    throw std::runtime_error("Duplicate export symbol: " + exp.name);
                symbolMap[exp.name] = std::make_pair(&src, &exp);
            }
        }

        if (!symbolMap.count(entryPoint))
            throw std::runtime_error("Entry point not found: " + entryPoint);

        toProcess.push(entryPoint);
        while (!toProcess.empty()) {
            std::string func = toProcess.front();
            toProcess.pop();

            if (resolvedAddresses.count(func))
                continue;

            std::cout << "[linkOutput] Processing function: " << func << std::endl;

            const Source* src = symbolMap[func].first;
            const Export* exp = symbolMap[func].second;

            resolvedAddresses[func] = 0;
            orderedFunctions.push_back(std::make_pair(src, exp));

            uint32_t funcEnd = findFunctionEnd(src, exp);

            for (const auto & imp : src->imports) {
                for (auto refOffset : imp.reference) {
                    if (refOffset >= exp->offset && refOffset < funcEnd) {
                        toProcess.push(imp.name);
                        break;
                    }
                }
            }
        }

        std::cout << "[linkOutput] Final function order:" << std::endl;
        for (size_t i = 0; i < orderedFunctions.size(); ++i) {
            std::cout << " - " << orderedFunctions[i].second->name << std::endl;
        }

        std::vector<uint8_t> outputCode;

        for (size_t i = 0; i < orderedFunctions.size(); ++i) {
            const Source* src = orderedFunctions[i].first;
            const Export* exp = orderedFunctions[i].second;

            uint32_t newOffset = outputCode.size();
            resolvedAddresses[exp->name] = newOffset;

            uint32_t end = findFunctionEnd(src, exp);
            uint32_t len = end - exp->offset;

            outputCode.insert(outputCode.end(), src->code.begin() + exp->offset, src->code.begin() + exp->offset + len);
        }
        for (const auto& srcImp : m_ObjectFiles) {
          for (const auto& imp : srcImp.imports) {
              if (!resolvedAddresses.count(imp.name))
                  throw std::runtime_error("Missing function for import: " + imp.name);
              uint32_t targetAddr = resolvedAddresses[imp.name];
      
              for (uint32_t ref : imp.reference) {
                  for (size_t i = 0; i < orderedFunctions.size(); ++i) {
                      const Source* srcF = orderedFunctions[i].first;
                      const Export* expF = orderedFunctions[i].second;
                      uint32_t start = expF->offset;
                      uint32_t end = findFunctionEnd(srcF, expF);
                      uint32_t baseAddr = resolvedAddresses[expF->name];
      
                      if (ref >= start && ref < end) {
                          uint32_t localOffset = baseAddr + (ref - start);
                          if (localOffset + 4 > outputCode.size())
                              throw std::runtime_error("Invalid address patch");
      
                          std::cout << "[linkOutput] Patching " << imp.name << " at " << localOffset
                                    << " with address " << targetAddr << std::endl;
      
                          std::memcpy(&outputCode[localOffset], &targetAddr, sizeof(uint32_t));
                      }
                  }
              }
          }
      }
      

        std::ofstream out(outFileName, std::ios::binary);
        if (!out)
            throw std::runtime_error("Failed to open output file: " + outFileName);

        out.write(reinterpret_cast<const char*>(outputCode.data()), outputCode.size());
        std::cout << "[linkOutput] Wrote output file: " << outFileName
                  << " (" << outputCode.size() << " bytes)" << std::endl;
    }
};


#ifndef __PROGTEST__
int main ()
{
  CLinker () . addFile ( "0in0.o" ) . linkOutput ( "0out", "strlen" );

  CLinker () . addFile ( "1in0.o" ) . linkOutput ( "1out", "main" );

  CLinker () . addFile ( "2in0.o" ) . addFile ( "2in1.o" ) . linkOutput ( "2out", "main" );

  CLinker () . addFile ( "3in0.o" ) . addFile ( "3in1.o" ) . linkOutput ( "3out", "towersOfHanoi" );

  try
  {
    CLinker () . addFile ( "4in0.o" ) . addFile ( "4in1.o" ) . linkOutput ( "4out", "unusedFunc" );
    assert ( "missing an exception" == nullptr );
  }
  catch ( const std::runtime_error & e )
  {
    // e . what (): Undefined symbol qsort
  }
  catch ( ... )
  {
    assert ( "invalid exception" == nullptr );
  }

  try
  {
    CLinker () . addFile ( "5in0.o" ) . linkOutput ( "5out", "main" );
    assert ( "missing an exception" == nullptr );
  }
  catch ( const std::runtime_error & e )
  {
    // e . what (): Duplicate symbol: printf
  }
  catch ( ... )
  {
    assert ( "invalid exception" == nullptr );
  }

  try
  {
    CLinker () . addFile ( "6in0.o" ) . linkOutput ( "6out", "strlen" );
    assert ( "missing an exception" == nullptr );
  }
  catch ( const std::runtime_error & e )
  {
    // e . what (): Cannot read input file
  }
  catch ( ... )
  {
    assert ( "invalid exception" == nullptr );
  }

  try
  {
    CLinker () . addFile ( "7in0.o" ) . linkOutput ( "7out", "strlen2" );
    assert ( "missing an exception" == nullptr );
  }
  catch ( const std::runtime_error & e )
  {
    // e . what (): Undefined symbol strlen2
  }
  catch ( ... )
  {
    assert ( "invalid exception" == nullptr );
  }
  std::cout<< "SUCCES" << std::endl;
  return EXIT_SUCCESS;
}
#endif /* __PROGTEST__ */